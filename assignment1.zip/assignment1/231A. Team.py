from os.path import split
a=0
b=0
n=int(input())
for i in range(n):
    answer1=input()
    answer1=answer1.split()
    for j in range(3):
        a=a+(eval(answer1[j])==1)
    if a>=2:
        b=b+1
    a=0
print(b)

