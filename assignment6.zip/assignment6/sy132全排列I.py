from itertools import permutations
n=int(input())
lst=[x for x in range(1,n+1)]
ans=list(permutations(lst))
ans.sort()
for i in range(len(ans)):
    print(' '.join(map(str,ans[i])))