def hnt(n,start,mid,stop):
    if n==0 or n%1!=0:
        return
    hnt(n-1,start,stop,mid)
    print(f'{start}->{stop}')
    hnt(n-1,mid,start,stop)
n=int(input())
print(pow(2,n)-1)
hnt(n,'A','B','C')