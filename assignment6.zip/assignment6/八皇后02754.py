from itertools import permutations
a=[1,2,3,4,5,6,7,8]
queen=list(permutations(a))
ans=[]
for i in range(len(queen)):
    for j in range(8):
        for k in range(8):
            if abs(queen[i][j]-queen[i][k])==abs(j-k) and j!=k:
                queen[i]=tuple(list(queen[i])+['A'])
for i in range(len(queen)):
    if 'A' not in queen[i]:
        queen[i]=''.join(map(str,list(queen[i])))
        ans.append(queen[i])
ans.sort()
n=int(input())
for i in range(n):
    print(ans[int(input())-1])