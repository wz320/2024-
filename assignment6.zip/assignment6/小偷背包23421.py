n,b=map(int,input().split())
price=list(map(int,input().split()))
weight=list(map(int,input().split()))
item=[]
for i in range(n):
    item.append((price[i],weight[i]))
dp=[0]*(b+1)
for price,weight in item:
    for j in range(b,weight-1,-1):
        dp[j]=max(dp[j],dp[j-weight]+price)
print(dp[-1])