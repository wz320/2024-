k=int(input())
missile=list(map(int,input().split()))
hit=[1]*k
for i in range(1,k):
    for j in range(i):
        if missile[i]<=missile[j]:
            hit[i]=max(hit[i],hit[j]+1)
print(max(hit))