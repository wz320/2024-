p=int(input())
n=list(map(int,input().split()))
n.sort()
ans=0
left=0
right=len(n)-1
while left<=right:
    if n[left]<=p:
        ans+=1
        p-=n[left]
        left+=1
    else:
        if right==left:
            break
        p+=n[right]
        ans-=1
        if ans<0:
            ans=0
            break
        right-=1
print(ans)