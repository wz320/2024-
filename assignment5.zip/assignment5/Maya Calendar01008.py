H={'pop': 1, 'no': 2, 'zip': 3, 'zotz': 4, 'tzec': 5, 'xul': 6, 'yoxkin': 7, 'mol': 8, 'chen': 9, 'yax': 10, 'zac': 11, 'ceh': 12, 'mac': 13, 'kankin': 14, 'muan': 15, 'pax': 16, 'koyab': 17, 'cumhu': 18, 'uayet': 19}
T={ 1: 'imix', 2: 'ik', 3: 'akbal', 4: 'kan', 5: 'chicchan', 6: 'cimi', 7: 'manik', 8: 'lamat', 9: 'muluk', 10: 'ok', 11: 'chuen', 12: 'eb', 13: 'ben', 14: 'ix', 15: 'mem', 16: 'cib', 17: 'caban', 18: 'eznab', 19: 'canac', 0: 'ahau'}
n=int(input())
lst=[]
ans=[]
for i in range(n):
    date=input().split()
    date[0]=int(date[0][:-1])
    date[1]=H[date[1]]
    date[-1]=int(date[2])
    date.append(date[0]+date[1]*20-20+1)
    lst.append(date[2]*365+date[-1])
print(n)
for i in range(n):
    year=(lst[i]-1)//260
    months=T[lst[i]%20]
    if lst[i]%13==0:
        day=13
    else:
        day=lst[i]%13
    print(day,months,year)