from math import sqrt
def radar(n,d,total):
    lst=[]
    ans=1
    if d<=0:
        return -1
    for x,y in total:
        if y>d:
            return -1
        D=sqrt(d*d-y*y)
        lst.append((x-D,x+D))
    lst.sort(key=lambda x: x[0])
    R=lst[0]
    for i in range(1,n):
        if lst[i][0]>=R[0] and lst[i][1]<=R[1]:
            R=(lst[i][0],lst[i][1])
        if lst[i][0]>R[1]:
            R=(lst[i][0],lst[i][1])
            ans+=1
    return ans
case=1
while True:
    n,d=map(int,input().split())
    if n==0 and d==0:
        break
    total=[]
    for i in range(n):
        x,y=map(int,input().split())
        total.append((x,y))
    print(f'Case {case}: {radar(n,d,total)}')
    _=input()
    case+=1