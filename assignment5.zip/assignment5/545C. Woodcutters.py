n=int(input())
trees=[]
if n<2:
    _=input()
    print(n)
    exit()
ans=2
for i in range(n):
    tree=tuple(map(int,input().split()))
    trees.append(tree)
trees.sort(key=lambda x: x[0])
for i in range(1,n-1):
    if trees[i][0]-trees[i][-1]>trees[i-1][0]:
        ans+=1
        continue
    elif trees[i][0]+trees[i][-1]<trees[i+1][0]:
        ans+=1
        trees[i]=(trees[i][0]+trees[i][-1],trees[i][-1])
print(ans)