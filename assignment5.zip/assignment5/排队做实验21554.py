n=int(input())
lst=list(map(int,input().split()))
time_=0
sequence=[]
for i in range(n):
    lst[i]=(i+1,lst[i])
lst.sort(key=lambda x: x[-1])
for i in range(n):
    sequence.append(str(lst[i][0]))
print(' '.join(sequence))
for i in range(n):
    time_+=(n-i-1)*lst[i][-1]
time_/=n
print(f'{time_:.2f}')