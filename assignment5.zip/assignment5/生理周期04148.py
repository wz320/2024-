shijian=1
while 1:
    p,e,i,d=map(int,input().split())
    if {d,p,e,i}=={-1}:
        break
    p=p%23
    e=e%28
    i=i%33
    ans=d+1
    while 1:
        if (ans-p)%23!=0 or (ans-e)%28!=0 or (ans-i)%33!=0:
            ans+=1
        else:
            ans-=d
            break
    print(f'Case {shijian}: the next triple peak occurs in {ans} days.')
    shijian+=1