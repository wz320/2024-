def move(m,length,stones):
    removed=0
    last=stones[0]
    for i in range(1,len(stones)):
        if stones[i]-last<length:
            removed+=1
        else:
            last=stones[i]
        if removed>m:
            return False
    return True
def min_distance(l,n,m,stones):
    stones=[0]+stones+[l]
    short=1
    long=l
    result=0
    while short<=long:
        mid=(long+short)//2
        if move(m,mid,stones):
            result=mid
            short=mid+1
        else:
            long=mid-1
    return result
l,n,m=map(int,input().split())
stones=[]
for i in range(n):
    stones.append(int(input()))
print(min_distance(l,n,m,stones))