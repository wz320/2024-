from copy import deepcopy
d=[(0,0),(1,0),(0,1),(-1,0),(0,-1)]
def check(x,y):
    if 0<=x<5 and 0<=y<6:
        return True
    return False
def press(x,y,bulbs):
    for dx,dy in d:
        tx,ty=x+dx,y+dy
        if check(tx,ty):
            bulbs[tx][ty]^=1
bulbs=[]
for i in range(5):
    bulbs.append(list(map(int,input().split())))
for i in range(64):
    now=deepcopy(bulbs)
    solution=[[0]*6 for _ in range(5)]
    for j in range(6):
        if (i>>j)&1:
            solution[0][j]=1
            press(0,j,now)
    for j in range(1,5):
        for k in range(6):
            if now[j-1][k]==1:
                solution[j][k]=1
                press(j,k,now)
    if all(now[4][j]==0 for j in range(6)):
        for j in solution:
            print(*j)
        break