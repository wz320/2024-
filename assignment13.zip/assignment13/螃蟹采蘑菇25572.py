from collections import deque
d=[(1,0),(-1,0),(0,1),(0,-1)]
def check(x1,y1,x2,y2,n):
    if 0<=x1<n and 0<=y1<n and 0<=x2<n and 0<=y2<n:
        return True
    return False
def bfs(x1,y1,x2,y2):
    q=deque([(x1,y1,x2,y2)])
    inq={(x1,y1,x2,y2)}
    while q:
        x1,y1,x2,y2=q.popleft()
        if maze[x1][y1]==9 or maze[x2][y2]==9:
            return True
        for dx,dy in d:
            tx1,ty1,tx2,ty2=x1+dx,y1+dy,x2+dx,y2+dy
            if check(tx1,ty1,tx2,ty2,n):
                if maze[tx1][ty1]!=1 and maze[tx2][ty2]!=1 and (tx1,ty1,tx2,ty2) not in inq:
                    inq.add((tx1,ty1,tx2,ty2))
                    q.append((tx1,ty1,tx2,ty2))
    return False
def find(x,y):
    for dx,dy in d:
        tx,ty=x+dx,y+dy
        if check(tx,ty,tx,ty,n):
            if maze[tx][ty]==5:
                return [tx,ty]
n=int(input())
maze=[]
for i in range(n):
    maze.append(list(map(int,input().split())))
for i in range(n):
    for j in range(n):
        if maze[i][j]==5:
            lo=[i,j]+find(i,j)
            break
if bfs(lo[0],lo[1],lo[2],lo[3]):
    print('yes')
else:
    print('no')