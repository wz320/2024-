d=[(0,1),(0,-1),(1,0),(-1,0)]
def check(x,y,r,c):
    if 0<=x<r and 0<=y<c:
        return True
    return False
r,c=map(int,input().split())
field=[]
dp=[[0]*c for _ in range(r)]
for i in range(r):
    field.append(list(map(int,input().split())))
def dfs(x,y):
    if dp[x][y]>0:
        return dp[x][y]
    for dx,dy in d:
        tx,ty=x+dx,y+dy
        if check(tx,ty,r,c) and field[tx][ty]<field[x][y]:
            dp[x][y]=max(dp[x][y],dfs(tx,ty)+1)
    return dp[x][y]
ans=0
for i in range(r):
    for j in range(c):
        ans=max(ans,dfs(i,j))
print(ans+1)