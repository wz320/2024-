m=int(input())
n=int(input())
nums=input().split()
for i in range(n):
    for j in range(i,n):
        if int(nums[i]+nums[j])<int(nums[j]+nums[i]):
            nums[i],nums[j] = nums[j],nums[i]
dp=[0]*(m+1)
t=[0]*(m+1)
for i in nums:
    for j in range(len(i),m+1):
        dp[j]=max(dp[j],int(str(t[j-len(i)])+i))
    t=dp[:]
print(dp[-1])