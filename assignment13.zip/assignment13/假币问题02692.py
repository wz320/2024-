n = int(input())
def check(coins, case):
    for item in case:
        left, right, result = item.split()
        lw = sum(coins[i] for i in left)
        rw = sum(coins[i] for i in right)
        if lw == rw and result != 'even':
            return False
        elif lw < rw and result != 'down':
            return False
        elif lw > rw and result != 'up':
            return False
    return True
for _ in range(n):
    case = [input() for _ in range(3)]
    for counterfeit in 'ABCDEFGHIJKL':
        found = False
        for weight in [-1, 1]:
            coins = {coin: 0 for coin in 'ABCDEFGHIJKL'}
            coins[counterfeit] = weight
            if check(coins, case):
                found = True
                tag = "light" if weight == -1 else "heavy"
                print(f'{counterfeit} is the counterfeit coin and it is {tag}.')
                break
        if found:
            break