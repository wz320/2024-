n,d=map(int,input().split())
tall=[]
ans=[]
for i in range(n):
    tall.append(int(input()))
while tall:
    zancun=[]
    max_=tall[0]
    min_=tall[0]
    for j in range(len(tall)):
        h=tall.pop(0)
        if abs(h-max_)<=d and abs(h-min_)<=d:
            zancun.append(h)
        else:
            tall.append(h)
        max_=max(h,max_)
        min_=min(h,min_)
    ans+=sorted(zancun)
for k in range(n):
    print(ans[k])