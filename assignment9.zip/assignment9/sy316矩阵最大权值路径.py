directions=[(0,1),(0,-1),(1,0),(-1,0)]
def dfs(x,y,now):
    global maxv,routes
    if x==n-1 and y==m-1:
        if now>maxv:
            maxv=now
            routes=nowroutes[:]
        return
    visit[x][y]=True
    for dx,dy in directions:
        tx,ty=x+dx,y+dy
        if 0<=tx<n and 0<=ty<m and not visit[tx][ty]:
            now1=now+matrix[tx][ty]
            nowroutes.append((tx,ty))
            dfs(tx,ty,now1)
            nowroutes.pop()
    visit[x][y]=False
n,m=map(int,input().split())
matrix=[list(map(int, input().split())) for _ in range(n)]
maxv=-float("inf")
routes=[]
nowroutes= [(0, 0)]
visit=[[False]*m for _ in range(n)]
dfs(0,0,matrix[0][0])
for x,y in routes:
    print(x+1,y+1)