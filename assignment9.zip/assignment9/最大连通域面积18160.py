num=0
dire=[(-1,-1),(-1,0),(-1,1),(0,-1),(0,1),(1,-1),(1,0),(1,1)]
def dfs(i,j):
    global num
    if m[i][j]=='.': return
    m[i][j]='.'
    num+=1
    for k in range(len(dire)):
        dfs(i+dire[k][0],j+dire[k][1])
n=int(input())
for i in range(n):
    N,M=map(int,input().split())
    m=[['.' for _ in range(M+2)] for _ in range(N+2)]
    ans=0
    for _ in range(1,N+1):
        m[_][1:-1]=input()
    for j in range(1,N+1):
        for k in range(1,M+1):
            if m[j][k]=='W':
                num=0
                dfs(j,k)
                ans=max(ans,num)
    print(ans)