import math
def check(a,j):
    if j==len(a):
        return True
    now=0
    for i in range(j,len(a)):
        now=now*10+a[i]
        if math.sqrt(now)%1==0 and now!=0:
            if check(a,i+1):
                return True
    return False
a=[int(x) for x in input()]
if check(a,0):
    print('Yes')
else:
    print('No')