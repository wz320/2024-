chessboard=[]
ans=0
d=[(2,-1),(2,1),(-2,-1),(-2,1),(1,-2),(1,2),(-1,-2),(-1,2)]
def horse(step,x,y):
    if step==m*n:
        global ans
        ans+=1
        return
    for dx,dy in d:
        tx=x+dx
        ty=y+dy
        if 0<=tx<n and 0<=ty<m and chessboard[tx][ty]==False:
            chessboard[tx][ty]=True
            horse(step+1,tx,ty)
            chessboard[tx][ty]=False
T=int(input())
for i in range(T):
    ans=0
    n,m,x,y=map(int,input().split())
    chessboard=[[False for _ in range(m)] for _ in range(n)]
    chessboard[x][y]=True
    horse(1,x,y)
    print(ans)