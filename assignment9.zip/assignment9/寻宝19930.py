from collections import deque
def bfs(matrix):
    n, m = len(matrix), len(matrix[0])
    inq = [[False] * m for _ in range(n)]
    d = [(0, 1), (0, -1), (1, 0), (-1, 0)]
    def check(x, y):
        return 0 <= x < n and 0 <= y < m and not inq[x][y] and matrix[x][y] != 2
    q = deque([(0, 0, 0)])
    inq[0][0] = True
    while q:
        nx, ny, step = q.popleft()
        if matrix[nx][ny] == 1:
            return step
        for dx, dy in d:
            tx, ty = nx + dx, ny + dy
            if check(tx, ty):
                inq[tx][ty] = True
                q.append((tx, ty, step + 1))
    return 'NO'
n, m = map(int, input().split())
matrix = [list(map(int, input().split())) for _ in range(n)]
print(bfs(matrix))