from collections import defaultdict
n=int(input())
lst=defaultdict(int)
for i in list(map(int,input().split())):
    lst[i]+=1
dp0=[0]*(max(list(lst.keys()))+1)
dp1=[0]*(max(list(lst.keys()))+1)
for i in range(1,max(lst.keys())+1):
    dp0[i]=max(dp0[i-1],dp1[i-1])
    dp1[i]=dp0[i-1]+lst[i]*i
print(max(dp0[-1],dp1[-1]))