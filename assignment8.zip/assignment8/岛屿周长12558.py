directions=[(0,1),(0,-1),(1,0),(-1,0)]
def dfs(i,j,x):
    C=4
    x=2
    for dx,dy in directions:
        tx=i+dx
        ty=j+dy
        if 0<=tx<n and 0<=ty<m:
            if matrix[tx][ty]==1:
                C-=1
    return C
n,m=map(int,input().split())
matrix=[]
ans=0
for i in range(n):
    matrix.append(list(map(int,input().split())))
for i in range(n):
    for j in range(m):
        if matrix[i][j]==1:
            ans+=dfs(i,j,matrix[i][j])
print(ans)