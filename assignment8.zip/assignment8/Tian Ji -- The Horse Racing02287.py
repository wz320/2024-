from typing import List
from bisect import bisect_left
def tianjisaima(n:int,tian:List[int],king:List[int]) -> int:
    cnt=0
    buffer=[]
    for i in range(n):
        a=bisect_left(king,tian[i])
        if a>0:
            king.pop(a-1)
            cnt+=1
        else:
            buffer.append(tian[i])
    for i in range(len(buffer)):
        if buffer[i]<king[0]:
            cnt-=1
        else:
            king.pop(0)
    return cnt
while 1:
    n=int(input())
    if n==0:
        break
    tian=list(map(int,input().split()))
    king=list(map(int,input().split()))
    tian.sort()
    king.sort()
    print(tianjisaima(n,tian,king)*200)