d=int(input())
n=int(input())
garbage=[]
moskow=[[0]*1025 for _ in range(1025)]
for i in range(n):
    garbage.append(tuple(map(int,input().split())))
for x,y,z in garbage:
    for i in range(max(x-d,0),min(1024,x+d)+1):
        for j in range(max(y-d,0),min(y+d,1024)+1):
            moskow[i][j]+=z
MAX=num=0
for i in range(1025):
    for j in range(1025):
        if moskow[i][j]>MAX:
            MAX=moskow[i][j]
            num=1
        elif moskow[i][j]==MAX:
            num+=1
print(num,MAX)