goods=list(map(int,input().split(',')))
n=len(goods)
dp1=[0]*n
dp0=[0]*n
dp1[0]=dp0[0]=goods[0]
for i in range(1,n):
    dp1[i]=max(goods[i],dp1[i-1]+goods[i])
    dp0[i]=max(goods[i],dp0[i-1]+goods[i],dp1[i-1])
print(max(dp0))