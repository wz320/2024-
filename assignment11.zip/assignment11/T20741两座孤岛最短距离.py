from collections import deque
di=[(0,1),(1,0),(-1,0),(0,-1)]
lst=[]
a=0
def check(x,y,n):
    if 0<=x<n and 0<=y<n:
        return True
    return False
def bfs(map,lst):
    step=0
    q=deque()
    inq=set()
    for x,y in lst:
        q.append((x,y,step))
        inq.add((x,y))
    while q:
        x,y,step=q.popleft()
        if map[x][y]==1:
            return step-1
        for dx,dy in di:
            tx,ty=x+dx,y+dy
            if check(tx,ty,n) and (tx,ty) not in inq:
                if map[tx][ty]!=2:
                    q.append((tx,ty,step+1))
                    inq.add((tx,ty))
def dfs(x,y,n,map):
    global lst
    lst.append((x,y))
    map[x][y]=2
    for dx,dy in di:
        tx,ty=x+dx,y+dy
        if check(tx,ty,n):
            if Map[tx][ty]==1:
                dfs(tx,ty,n,map)
n=int(input())
Map=[]
for i in range(n):
    Map.append([int(x) for x in input()])
for i in range(n):
    for j in range(n):
        if Map[i][j]==1:
            dfs(i,j,n,Map)
            a=1
            break
    if a:
        break
print(bfs(Map,lst))