n=int(input())
king=tuple(map(int,input().split()))
minister=[]
for i in range(n):
    minister.append(tuple(map(int,input().split())))
minister.sort(key=lambda x:x[0]*x[1],reverse=True)
num=king[0]
for i in range(1,n):
    num*=minister[i][0]
print(num//minister[0][1])