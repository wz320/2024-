ans=0
def fry(k,t):
    global ans
    total=sum(t)
    if max(t)<=total//k:
        ans=total/k
        return
    elif k==1:
        ans=total
        return
    else:
        fry(k-1,t[1:])
n,k=map(int,input().split())
t=list(map(int,input().split()))
t.sort(reverse=True)
fry(k,t)
print(f'{ans:.3f}')