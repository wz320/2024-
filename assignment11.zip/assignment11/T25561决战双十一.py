result = float("inf")
n,m=map(int, input().split())
goods=[input().split() for _ in range(n)]
coupons=[input().split() for _ in range(m)]
def dfs(goods,coupons,item=0,total=0,store_price=[0]*m):
    global result
    if item==n:
        nowcoupon=0
        for i in range(m):
            store=0
            for coupon in coupons[i]:
                a,b=map(int,coupon.split('-'))
                if store_price[i]>=a:
                    store=max(store,b)
            nowcoupon+=store
        result=min(result,total-(total//300)*50-nowcoupon)
        return
    for _ in goods[item]:
        i,p =map(int,_.split(':'))
        store_price[i-1]+=p
        dfs(goods,coupons,item+1,total+p,store_price)
        store_price[i-1]-=p
dfs(goods, coupons)
print(result)