pig=[]
min_=[]
while 1:
    try:
        sentence=input()
        if sentence=='min':
            if min_:
                print(min_[-1])
        elif sentence=='pop':
            if pig:
                pig.pop()
                min_.pop()
        else:
            a=sentence.split()
            pig.append(int(a[1]))
            if min_:
                if min_[-1]>int(a[1]):
                    min_.append(int(a[1]))
                else:
                    min_.append(min_[-1])
            else:
                min_.append(int(a[1]))
    except EOFError:
        break