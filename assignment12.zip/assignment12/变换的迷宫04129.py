from collections import deque
dire=[(1,0),(-1,0),(0,1),(0,-1)]
T=int(input())
def check(x,y,r,c):
    if 0<=x<r and 0<=y<c:
        return True
    return False
def bfs(start,end,maze):
    x1=start[0]
    y1=start[1]
    visit={(x1,y1,0)}
    q=deque([(x1,y1,0)])
    while q:
        x,y,t=q.popleft()
        for dx,dy in dire:
            tx,ty=x+dx,y+dy
            nt=(t+1)%k
            if check(tx,ty,r,c) and (tx,ty,nt) not in visit:
                if (tx,ty)==end:
                    return t+1
                elif maze[tx][ty]!=1 or nt==0:
                    q.append((tx,ty,t+1))
                    visit.add((tx,ty,nt))
    return 'Oop!'
for i in range(T):
    r,c,k=map(int,input().split())
    maze=[[0]*c for _ in range(r)]
    for j in range(r):
        s=input()
        for _ in range(c):
            if s[_]=='#':
                maze[j][_]=1
            elif s[_]=='S':
                start=(j,_)
            elif s[_]=='E':
                end=(j,_)
    print(bfs(start,end,maze))