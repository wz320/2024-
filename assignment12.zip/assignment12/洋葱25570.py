from math import ceil
def distance(x,y,n):
    return min(x,y,n-x-1,n-y-1)
n=int(input())
onion=[]
for i in range(n):
    onion.append(list(map(int,input().split())))
ans=[0]*ceil(n/2)
for i in range(n):
    for j in range(n):
        ans[distance(i,j,n)]+=onion[i][j]
print(max(ans))