import heapq
def max_drink(n,drinks):
    health=0
    drunk=[]
    for d in drinks:
        health+=d
        heapq.heappush(drunk,d)
        if health<0:
            if drunk:
                health-=drunk[0]
                heapq.heappop(drunk)
    return len(drunk)
n=int(input())
drinks=list(map(int,input().split()))
print(max_drink(n,drinks))