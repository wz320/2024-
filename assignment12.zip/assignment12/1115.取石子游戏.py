ans=-1
def solve(a,b,cnt=0):
    global ans
    if (a//b>=2 or a==b) and cnt%2==0:
        ans=True
        return
    if (a//b>=2 or a==b) and cnt%2==1:
        ans=False
        return
    a,b=b,a-b
    solve(a,b,cnt+1)
while 1:
    a,b=map(int,input().split())
    if {a,b}=={0}:
        break
    if a>=b:
        solve(a,b)
    else:
        solve(b,a)
    if ans:
        print('win')
    else:
        print('lose')