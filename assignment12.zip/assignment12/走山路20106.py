import heapq
m,n,p=map(int,input().split())
maze=[]
data=[]
for i in range(m):
    maze.append(input().split())
di=[(1,0),(-1,0),(0,1),(0,-1)]
def check(x,y):
    if 0<=x<m and 0<=y<n and maze[x][y]!='#':
        return True
    return False
def dijkstra(x1,y1,x2,y2):
    q=[]
    distance=[[float('inf')]*n for _ in range(m)]
    if not check(x1,y1):
        return 'NO'
    distance[x1][y1]=0
    heapq.heappush(q,(0,x1,y1))
    while q:
        d,x,y=heapq.heappop(q)
        if x==x2 and y==y2:
            return d
        h=int(maze[x][y])
        for dx,dy in di:
            tx,ty=x+dx,y+dy
            if check(tx,ty):
                if distance[tx][ty]>d+abs(int(maze[tx][ty])-h):
                    distance[tx][ty]=d+abs(int(maze[tx][ty])-h)
                    heapq.heappush(q,(distance[tx][ty],tx,ty))
    return 'NO'
for i in range(p):
    x1,y1,x2,y2=map(int,input().split())
    print(dijkstra(x1,y1,x2,y2))