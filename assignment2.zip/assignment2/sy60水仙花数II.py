a,b=map(int,input().split())
answer=[]
for i in range(a,b+1):
    h=i//100
    t=(i%100)//10
    g=i%10
    if i==h*h*h+t*t*t+g*g*g:
        answer.append(i)
    else:
        pass
if len(answer)!=0:
    print(' '.join(map(str,answer)))
else:
    print('NO')