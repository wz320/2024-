from collections import deque
d=[(1,0),(-1,0),(0,1),(0,-1)]
def check(x,y,w,h):
    if 0<=x<h+2 and 0<=y<w+2:
        return True
    return False
def bfs(pair,board,w,h):
    x1=pair[0][0]
    y1=pair[0][1]
    x2=pair[1][0]
    y2=pair[1][1]
    q=deque([(x1,y1,-1,0)])
    visit={(x1,y1,-1)}
    segment=[]
    while q:
        x,y,di,seg=q.popleft()
        if x==x2 and y==y2:
            segment.append(seg)
            break
        for i,(dx,dy) in enumerate(d):
            tx,ty=x+dx,y+dy
            if check(tx,ty,w,h) and not((tx,ty,i) in visit):
                newdi=i
                newseg=seg
                if newdi!=di:
                    newseg+=1
                if tx==x2 and ty==y2:
                    segment.append(newseg)
                    continue
                if board[tx][ty]!=1:
                    visit.add((tx,ty,newdi))
                    q.append((tx,ty,newdi,newseg))
    if len(segment)==0:
        return -1
    return min(segment)
cnt=0
while 1:
    cnt+=1
    w,h=map(int,input().split())
    if w==h==0:
        break
    board=[[0]*(w+2) for _ in range(h+2)]
    for i in range(1,h+1):
        string=input()
        for j in range(1,w+1):
            if string[j-1]=='X':
                board[i][j]=1
    pairs=[]
    while 1:
        y1,x1,y2,x2=map(int,input().split())
        if y1==x1==y2==x2==0:
            break
        pairs.append([(x1,y1,-1,0),(x2,y2)])
    print(f'Board #{cnt}:')
    for i in range(len(pairs)):
        seg=bfs(pairs[i],board,w,h)
        if seg==-1:
            print(f'Pair {i+1}: impossible.')
        else:
            print(f'Pair {i+1}: {seg} segments.')
    print()