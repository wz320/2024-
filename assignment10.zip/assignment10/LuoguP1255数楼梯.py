n=int(input())
dp=[1]*n
if n==1:
    print(1)
elif n==2:
    print(2)
else:
    dp[1]=2
    for i in range(2,n):
        dp[i]=dp[i-1]+dp[i-2]
    print(dp[-1])