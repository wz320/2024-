n=int(input())
if n==1:
    print(1)
else:
    dp=[1]*n
    dp[1]=2
    for i in range(2,n):
        dp[i]=sum(dp[:i+1])
    print(dp[-1])