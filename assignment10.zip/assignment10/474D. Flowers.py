n,k=map(int,input().split())
dp=[1]+[0]*pow(10,5)
s=[1]+[0]*pow(10,5)
for i in range(1,pow(10,5)+1):
    if i>=k:
        dp[i]=(dp[i-1]+dp[i-k])%(pow(10,9)+7)
    else:
        dp[i]=dp[i-1]%(pow(10,9)+7)
    s[i]=(dp[i]+s[i-1])%(pow(10,9)+7)
for i in range(n):
    a,b=map(int,input().split())
    print((s[b]-s[a-1])%(pow(10,9)+7))