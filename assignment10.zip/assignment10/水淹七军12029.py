import sys
from collections import deque
dire=[(1,0),(-1,0),(0,1),(0,-1)]
def bfs(wx,wy,ditu,water):
    h=ditu[wx][wy]
    q=deque([(wx,wy,h)])
    while q:
        x,y,h=q.popleft()
        for dx,dy in dire:
            tx,ty=x+dx,y+dy
            if 0<=tx<m and 0<=ty<n and ditu[tx][ty]<h:
                if water[tx][ty]<h:
                    water[tx][ty]=h
                    q.append((tx,ty,h))
input=sys.stdin.read
data=input().split()
k=int(data[0])
result=[]
lo=1
for i in range(k):
    m,n=map(int,data[lo:lo+2])
    lo+=2
    ditu=[]
    for j in range(m):
        ditu.append(list(map(int,data[lo:lo+n])))
        lo+=n
    sx,sy=map(int,data[lo:lo+2])
    sx,sy=sx-1,sy-1
    lo+=2
    p=int(data[lo])
    lo+=1
    water=[[0]*n for _ in range(m)]
    for j in range(p):
        wx,wy=map(int,data[lo:lo+2])
        lo+=2
        wx,wy=wx-1,wy-1
        if ditu[wx][wy]<=ditu[sx][sy]:
            continue
        bfs(wx,wy,ditu,water)
    if water[sx][sy]!=0:
        result.append('Yes')
    else:
        result.append('No')
sys.stdout.write("\n".join(result)+"\n")