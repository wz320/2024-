T={'negative':-1,'one':1,'two':2,'three':3, 'four':4, 'five':5, 'six':6, 'seven':7, 'eight':8, 'nine':9, 'ten':10, 'eleven':11, 'twelve':12, 'thirteen':13, 'fourteen':14, 'fifteen':15, 'sixteen':16, 'seventeen':17, 'eighteen':18, 'nineteen':19, 'twenty':20, 'thirty':30, 'forty':40, 'fifty':50, 'sixty':60, 'seventy':70, 'eighty':80, 'ninety':90, 'hundred':100, 'thousand':1000, 'million':1000000}
num=input().split()
ans=[]
number=0
for i in range(len(num)):
    num[i]=T[num[i]]
if num[0]==-1:
    num.pop(0)
    ans.append(-1)
n=num[0]
for i in range(1,len(num)):
    if num[i]>num[i-1]:
        if num[i] in [1000,1000000]:
            n*=num[i]
            ans.append(n)
            n=0
        else:
            n*=num[i]
    else:
        n+=num[i]
ans.append(n)
if ans[0]==-1:
    number=-1*(sum(ans[1:]))
else:
    number=sum(ans)
print(number)