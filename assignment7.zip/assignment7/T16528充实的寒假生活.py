n=int(input())
activity=[]
dp=[0]*63
for i in range(n):
    a,b=map(int,input().split())
    activity.append((a+1,b+1))
activity.sort()
for i in range(n):
    for j in range(activity[i][1],62):
        dp[j]=max(dp[j],dp[activity[i][0]-1]+1)
print(max(dp))