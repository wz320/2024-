n,m=map(int,input().split())
tv=list(map(int,input().split()))
tv.sort()
ans=0
time_=0
while 1:
    if tv[time_]>0:
        break
    ans-=tv[time_]
    time_+=1
    if time_==m:
        break
print(ans)