import math
prime=[False]*1000001
prime[2]=prime[3]=True
for x in range(1,1001):
    for y in range(1,1001):
        n=4*x*x+y*y
        if n<=1000000 and (n%12==1 or n%12==5):
            prime[n]=not prime[n]
        n=3*x*x+y*y
        if n<=1000000 and n%12==7:
            prime[n]=not prime[n]
        n=3*x*x-y*y
        if x>y and n<=1000000 and n%12==11:
            prime[n]=not prime[n]
for i in range(5,1001):
    if prime[i]:
        for j in range(i*i,1000001,i*i):
            prime[j]=False
def tprime(x):
    if math.sqrt(x)%1!=0:
        return 'NO'
    elif prime[int(math.sqrt(x))]==1:
        return 'YES'
    else:
        return 'NO'
n=int(input())
lst=list(map(int,input().split()))
for i in range(n):
    print(tprime(lst[i]))