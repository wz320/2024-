import math
n=int(input())
data=input().split()
maxlen=len(max(data,key=len))
data.sort(key=lambda x:x*math.ceil(3*maxlen/len(x)))
ans1=''.join(data)
ans2=''.join(reversed(data))
print(ans2,ans1)