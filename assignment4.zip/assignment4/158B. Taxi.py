import math
n=int(input())
people=list(map(int,input().split()))
people.sort(reverse=True)
p4=[x for x in people if x==4]
p3=[x for x in people[len(p4):] if x==3]
p2=[x for x in people[len(p4)+len(p3):] if x==2]
p1=[x for x in people[len(p4)+len(p3)+len(p2):] if x==1]
ans=len(p4)+len(p3)
if len(p3)>=len(p1):
    ans+=math.ceil(len(p2)/2)
else:
    if len(p2)%2==0:
        ans+=(len(p2)//2)
        ans+=math.ceil((len(p1)-len(p3))/4)
    else:
        ans+=(len(p2)//2)
        ans+=max(math.ceil((len(p1)-len(p3)-2)/4)+1,1)
print(ans)